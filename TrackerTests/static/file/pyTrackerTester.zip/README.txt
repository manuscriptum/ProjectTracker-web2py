This is a readme for the pyTrackerTester.py application by Kevin Westropp.
It is a standalone python program that you can use to test the 
Project Tracker Web Application.
The Tom Tester username and password should already be registered in Project Tracker. If you wish to test multiple times with this application, you must change the name of the Project or else the tests will fail because the project title will already exist. It runs and tests the basic functionality of the Project Tracker Application.
