#README for pyclient.py
by Kevin Westropp

This is a short tutorial on using the pyclient.py.
This python program is meant to be run locally and will communicate with the Project Tracker Web Application.
Import - It needs to be updated with the name of the application - (whatever you named in your install of web2py). It also assumes you have python (2.5 or 2.7) installed at the location usr/bin/python but can be altered if you have it installed somewhere else. 


It takes four command line arguments: 
1. %ProjectName - name of project, must already be created in Project Tracker
2. %NewTodoTask - this is the new todo task item description/text
3. %UserLastName - last name of you the user creating the new task
4. %AssigneeLastName - last name of who this task is being assigned to 

To run at command line type:
>>
user@os: python pyclient.py %ProjectName %NewTodoTask %UserLastName %AssigneeLastName


If you have any quesitons, please feel free to contact me at: mail@kevinpatrickwestropp.com