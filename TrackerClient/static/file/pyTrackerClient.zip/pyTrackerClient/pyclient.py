#!/usr/bin/python

# import for system variables
import sys

# import for xmlrpclib client
from xmlrpclib import ServerProxy

# parse argumetns into input list
input = sys.argv
if len(input)==5:
    print 'file= ' + input[0] + '; var1= ' + input[1] + '; var2= ' + input[2] + '; var3= ' + input[3] + '; var4= ' + input[4] 
    server = ServerProxy('http://127.0.0.1:8000/tracker/default/call/xmlrpc/')
    print server.addtask_rpc(input[1], input[2], input[3], input[4])
else:
    print "Please try again with 4 variables."

